package com.example.loginform;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText email;
    EditText password;
    Button btn;
    TextView tv;

    String Username="admin@gmail.com";
    String Password="123456789";

    boolean isValid=false;
    int counter = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        email=findViewById(R.id.email);
        password=findViewById(R.id.password);
        btn=findViewById(R.id.loginBtn);
        tv=findViewById(R.id.textView);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String inputEmail = email.getText().toString();
                String inputPassword = password.getText().toString();

                if (inputEmail.isEmpty() || inputPassword.isEmpty())
                {
                    Toast.makeText(MainActivity.this,"Please enter valid detials",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    isValid=validate(inputEmail, inputPassword);

                    if (!isValid){
                        counter--;

                        Toast.makeText(MainActivity.this,"Incorrect Credentials entered", Toast.LENGTH_SHORT).show();

                        tv.setText("No of Attempts remmining:" + counter);

                        if (counter==0){
                            btn.setEnabled(false);
                        }
                    }else {

                        Toast.makeText(MainActivity.this,"Login Sucessfully", Toast.LENGTH_SHORT).show();

                        //Second Activity

                        Intent intent=new Intent(MainActivity.this, HomePageActivity.class);
                        startActivity(intent);
                    }
                }
            }
        });
    }

    private boolean validate(String name, String password)
    {
        if (name.equals(Username) && password.equals(Password)){
            return true;
        }
        return  false;
    }

}